H2He_RT_magnus2023/

In the beginning of this summer I corresponded with Leigh regarding H2 and He CIA data. He said it would be helpful to have the H2-He rototranslational absorption covering all the way up to 4000 cm-1 in order to make a smooth merger with the fundamental band data. So, now I have extended my latest (final?) H2-He RT data set, on a somewhat coarser grid for the highest frequencies, and uploaded the files to google drive. The directory should be shared with both of you (I have added Leigh). Please let me know if it doesn\u2019t work.

The absorption is calculated with state of the art dipole and potential data. The anisotropy of the potential is included in the close coupling (CC) scattering calculation. The CC data is interpolated using the isotropic potential approximation as a guide. The basic idea of that method is similar to the machine learning scheme that I presented at the line shape conference about a year ago. 

Leigh:
Looks like the same grid is being used for <2400 cm-1, and other than right near 2000 cm-1 the calculations look practically identical.  Then after 2400 the absorption is calculated on a 100 cm-1 grid.  So it's safe to just adopt this entirely new directory and avoid the weird interpolation.
